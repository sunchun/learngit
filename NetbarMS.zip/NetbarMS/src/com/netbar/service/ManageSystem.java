package com.netbar.service;

import java.util.Date;

import com.netbar.dao.Computer;
import com.netbar.dao.ComputerDAO;
import com.netbar.dao.Landcumputer;
import com.netbar.dao.LandcumputerDAO;
import com.netbar.factory.HibernateSessionFactory;

public class ManageSystem {
	public int getState(int computerID)
	{
		ComputerDAO computerdao = new ComputerDAO();
		return computerdao.findById(computerID).getState();
	}
	
	public double getPrice(int computerID)
	{
		ComputerDAO computerdao = new ComputerDAO();
		return computerdao.findById(computerID).getPrice();
	}
	
	public void landComputer(String personID,int computerID,Date upTime)
	{
		Landcumputer landcumputer = new Landcumputer(personID, computerID, upTime);
		LandcumputerDAO landcomputerdao = new LandcumputerDAO();
		landcomputerdao.save(landcumputer);
		ComputerDAO computerdao = new ComputerDAO();
		double price = computerdao.findById(computerID).getPrice();
		Computer computer = new Computer(computerID,price,1);
		HibernateSessionFactory.getSession().clear();
		computerdao.save(computer);
		HibernateSessionFactory.getSession().flush();
	}
	
	public int logoutCompter(String personID,int computerID,Date downTime)
	{
		long between = 0;
		LandcumputerDAO landcomputerdao = new LandcumputerDAO();
		Landcumputer landcumputer = landcomputerdao.findById(personID);
		Date upTime = landcumputer.getUpTime();
		between = downTime.getTime() - upTime.getTime();
		ComputerDAO computerdao = new ComputerDAO();
		double price = computerdao.findById(computerID).getPrice();
		Computer computer = new Computer(computerID,price,0);
		HibernateSessionFactory.getSession().clear();
		computerdao.save(computer);
		HibernateSessionFactory.getSession().flush();
		HibernateSessionFactory.getSession().clear();
		landcomputerdao.delete(landcumputer);
		HibernateSessionFactory.getSession().flush();
		return (int) (between/(60 * 60 * 1000));
	}
	
	public double account(int hours,int computerID)
	{
		ComputerDAO computerdao = new ComputerDAO();
		return hours*computerdao.findById(computerID).getPrice();
	}
}
