package com.netbar.GUI;
import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;

import com.netbar.service.ManageSystem;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class mainGUI extends javax.swing.JFrame {
	private JPanel jPanel1;
	private JLabel jLabel17;
	private JLabel jLabel5;
	private ClockText jLabel16;
	private JLabel jLabel15;
	private JLabel jLabel14;
	private JLabel jLabel13;
	private JLabel jLabel12;
	private JLabel jLabel11;
	private JLabel jLabel10;
	private JLabel jLabel9;
	private JPanel jPanel2;
	private JLabel jLabel8;
	private JLabel jLabel7;
	private JLabel jLabel6;
	private JLabel jLabel4;
	private JLabel jLabel3;
	private JLabel jLabel2;
	private JLabel jLabel1;
	private JButton jButton8;
	private JButton jButton7;
	private JButton jButton6;
	private JButton jButton5;
	private JButton jButton4;
	private JButton jButton3;
	private JButton jButton2;
	private JButton jButton1;
	private JButton Up;
	private JButton Down;

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				mainGUI inst = new mainGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public mainGUI() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setLayout(null);
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, "Center");
				jPanel1.setLayout(null);
				ManageSystem ms = new ManageSystem();
				jPanel1.setBounds(0, 0, 626, 381);
				{
					if(ms.getState(101) == 0)
					{
						jButton1 = new JButton(new ImageIcon("pic/01.jpg"));
					}
					if(ms.getState(101) == 1)
					{
						jButton1 = new JButton(new ImageIcon("pic/02.jpg"));
					}
					jPanel1.add(jButton1);
					jButton1.setBounds(174, 75, 55, 52);
					jButton1.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							jButton1MouseClicked(evt);
						}
					});
				}
				{
					if(ms.getState(102) == 0)
					{
						jButton2 = new JButton(new ImageIcon("pic/01.jpg"));
					}
					if(ms.getState(102) == 1)
					{
						jButton2 = new JButton(new ImageIcon("pic/02.jpg"));
					}
					jPanel1.add(jButton2);
					jButton2.setBounds(288, 75, 57, 52);
					jButton2.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							jButton2MouseClicked(evt);
						}
					});
				}
				{
					if(ms.getState(103) == 0)
					{
						jButton3 = new JButton(new ImageIcon("pic/01.jpg"));
					}
					if(ms.getState(103) == 1)
					{
						jButton3 = new JButton(new ImageIcon("pic/02.jpg"));
					}
					jPanel1.add(jButton3);
					jButton3.setBounds(406, 75, 57, 52);
					jButton3.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							jButton3MouseClicked(evt);
						}
					});
				}
				{
					if(ms.getState(104) == 0)
					{
						jButton4 = new JButton(new ImageIcon("pic/01.jpg"));
					}
					if(ms.getState(104) == 1)
					{
						jButton4 = new JButton(new ImageIcon("pic/02.jpg"));
					}
					jPanel1.add(jButton4);
					jButton4.setBounds(512, 75, 55, 52);
					jButton4.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							jButton4MouseClicked(evt);
						}
					});
				}
				{
					if(ms.getState(201) == 0)
					{
						jButton5 = new JButton(new ImageIcon("pic/01.jpg"));
					}
					if(ms.getState(201) == 1)
					{
						jButton5 = new JButton(new ImageIcon("pic/02.jpg"));
					}
					jPanel1.add(jButton5);
					jButton5.setBounds(174, 171, 55, 50);
					jButton5.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							jButton5MouseClicked(evt);
						}
					});
				}
				{
					if(ms.getState(202) == 0)
					{
						jButton6 = new JButton(new ImageIcon("pic/01.jpg"));
					}
					if(ms.getState(202) == 1)
					{
						jButton6 = new JButton(new ImageIcon("pic/02.jpg"));
					}
					jPanel1.add(jButton6);
					jButton6.setBounds(288, 171, 57, 50);
					jButton6.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							jButton6MouseClicked(evt);
						}
					});
				}
				{
					if(ms.getState(203) == 0)
					{
						jButton7 = new JButton(new ImageIcon("pic/01.jpg"));
					}
					if(ms.getState(203) == 1)
					{
						jButton7 = new JButton(new ImageIcon("pic/02.jpg"));
					}
					jPanel1.add(jButton7);
					jButton7.setBounds(406, 171, 57, 50);
					jButton7.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							jButton7MouseClicked(evt);
						}
					});
				}
				{
					if(ms.getState(204) == 0)
					{
						jButton8 = new JButton(new ImageIcon("pic/01.jpg"));
					}
					if(ms.getState(204) == 1)
					{
						jButton8 = new JButton(new ImageIcon("pic/02.jpg"));
					}
					jPanel1.add(jButton8);
					jButton8.setBounds(512, 171, 55, 50);
					jButton8.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							jButton8MouseClicked(evt);
						}
					});
				}
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("101");
					jLabel1.setBounds(192, 132, 43, 17);
				}
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2);
					jLabel2.setText("102");
					jLabel2.setBounds(304, 132, 41, 17);
				}
				{
					jLabel3 = new JLabel();
					jPanel1.add(jLabel3);
					jLabel3.setText("103");
					jLabel3.setBounds(422, 132, 41, 17);
				}
				{
					jLabel4 = new JLabel();
					jPanel1.add(jLabel4);
					jLabel4.setText("104");
					jLabel4.setBounds(526, 132, 53, 17);
				}
				{
					jLabel5 = new JLabel();
					jPanel1.add(jLabel5);
					jLabel5.setText("201");
					jLabel5.setBounds(192, 232, 41, 17);
				}
				{
					jLabel6 = new JLabel();
					jPanel1.add(jLabel6);
					jLabel6.setText("202");
					jLabel6.setBounds(304, 232, 50, 17);
				}
				{
					jLabel7 = new JLabel();
					jPanel1.add(jLabel7);
					jLabel7.setText("203");
					jLabel7.setBounds(422, 232, 41, 17);
				}
				{
					jLabel8 = new JLabel();
					jPanel1.add(jLabel8);
					jLabel8.setText("204");
					jLabel8.setBounds(524, 232, 43, 17);
				}
				{
					jPanel2 = new JPanel();
					jPanel1.add(jPanel2);
					jPanel2.setBounds(0, 0, 162, 381);
					jPanel2.setLayout(null);
					jPanel2.setBackground(new java.awt.Color(192,192,192));
					{
						jLabel9 = new JLabel();
						jPanel2.add(jLabel9);
						jLabel9.setText("\u7535\u8111\u4fe1\u606f");
						jLabel9.setBounds(37, 5, 92, 31);
						jLabel9.setFont(new java.awt.Font("΢���ź�",1,14));
					}
					{
						jLabel10 = new JLabel();
						jPanel2.add(jLabel10);
						jLabel10.setText("\u7f16\u53f7\uff1a");
						jLabel10.setBounds(6, 56, 48, 25);
					}
					{
						jLabel11 = new JLabel();
						jPanel2.add(jLabel11);
						jLabel11.setBounds(54, 60, 76, 17);
					}
					{
						jLabel12 = new JLabel();
						jPanel2.add(jLabel12);
						jLabel12.setText("\u4ef7\u683c\uff1a");
						jLabel12.setBounds(6, 135, 48, 17);
					}
					{
						jLabel13 = new JLabel();
						jPanel2.add(jLabel13);
						jLabel13.setBounds(60, 135, 73, 17);
					}
					{
						jLabel14 = new JLabel();
						jPanel2.add(jLabel14);
						jLabel14.setText("\u72b6\u6001\uff1a");
						jLabel14.setBounds(6, 209, 48, 17);
					}
					{
						jLabel15 = new JLabel();
						jPanel2.add(jLabel15);
						jLabel15.setBounds(66, 209, 76, 17);
					}
					{
						jLabel17 = new JLabel();
						jPanel2.add(jLabel17);
						jLabel17.setText("\u6bcf\u5c0f\u65f6");
						jLabel17.setBounds(106, 135, 45, 17);
					}
				}
				{
					jLabel16 = new ClockText();
					jPanel1.add(jLabel16);
					jLabel16.setBounds(281, 11, 193, 52);
					jLabel16.setBackground(new java.awt.Color(192,192,192));
					jLabel16.setFont(new java.awt.Font("Microsoft YaHei UI",1,12));
				}
				{
					Up = new JButton(new ImageIcon("pic/left.gif"));
					jPanel1.add(Up);
					Up.setBounds(308, 308, 114, 39);
					Up.setText("\u4e0a\u673a");
					Up.setFont(new java.awt.Font("΢���ź�",1,14));
					Up.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							UpMouseClicked(evt);
						}
					});
				}
				{
					Down = new JButton(new ImageIcon("pic/right.gif"));
					jPanel1.add(Down);
					Down.setText("\u4e0b\u673a");
					Down.setBounds(451, 308, 111, 39);
					Down.setFont(new java.awt.Font("΢���ź�",1,14));
					Down.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							DownMouseClicked(evt);
						}
					});
				}
			}
			pack();
			this.setSize(642, 420);
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}
	
	private void jButton1MouseClicked(MouseEvent evt) {
		ManageSystem ms = new ManageSystem();
		jLabel11.setText("101");
		jLabel13.setText(Double.toString(ms.getPrice(101)));
		if(ms.getState(101) == 0)
		{
			jLabel15.setText("����");
		}
		if(ms.getState(101) == 1)
		{
			jLabel15.setText("����");
		}
	}
	
	private void jButton2MouseClicked(MouseEvent evt) {
		ManageSystem ms = new ManageSystem();
		jLabel11.setText("102");
		jLabel13.setText(Double.toString(ms.getPrice(102)));
		if(ms.getState(102) == 0)
		{
			jLabel15.setText("����");
		}
		if(ms.getState(102) == 1)
		{
			jLabel15.setText("����");
		}
	}
	
	private void jButton3MouseClicked(MouseEvent evt) {
		ManageSystem ms = new ManageSystem();
		jLabel11.setText("103");
		jLabel13.setText(Double.toString(ms.getPrice(103)));
		if(ms.getState(103) == 0)
		{
			jLabel15.setText("����");
		}
		if(ms.getState(103) == 1)
		{
			jLabel15.setText("����");
		}
	}
	
	private void jButton4MouseClicked(MouseEvent evt) {
		ManageSystem ms = new ManageSystem();
		jLabel11.setText("104");
		jLabel13.setText(Double.toString(ms.getPrice(104)));
		if(ms.getState(104) == 0)
		{
			jLabel15.setText("����");
		}
		if(ms.getState(104) == 1)
		{
			jLabel15.setText("����");
		}
	}
	
	private void jButton5MouseClicked(MouseEvent evt) {
		ManageSystem ms = new ManageSystem();
		jLabel11.setText("201");
		jLabel13.setText(Double.toString(ms.getPrice(201)));
		if(ms.getState(201) == 0)
		{
			jLabel15.setText("����");
		}
		if(ms.getState(201) == 1)
		{
			jLabel15.setText("����");
		}
	}
	
	private void jButton6MouseClicked(MouseEvent evt) {
		ManageSystem ms = new ManageSystem();
		jLabel11.setText("202");
		jLabel13.setText(Double.toString(ms.getPrice(202)));
		if(ms.getState(202) == 0)
		{
			jLabel15.setText("����");
		}
		if(ms.getState(202) == 1)
		{
			jLabel15.setText("����");
		}
	}
	
	private void jButton7MouseClicked(MouseEvent evt) {
		ManageSystem ms = new ManageSystem();
		jLabel11.setText("203");
		jLabel13.setText(Double.toString(ms.getPrice(203)));
		if(ms.getState(203) == 0)
		{
			jLabel15.setText("����");
		}
		if(ms.getState(203) == 1)
		{
			jLabel15.setText("����");
		}
	}
	
	private void jButton8MouseClicked(MouseEvent evt) {
		ManageSystem ms = new ManageSystem();
		jLabel11.setText("204");
		jLabel13.setText(Double.toString(ms.getPrice(204)));
		if(ms.getState(204) == 0)
		{
			jLabel15.setText("����");
		}
		if(ms.getState(204) == 1)
		{
			jLabel15.setText("����");
		}
	}
	
	public void skip()
	{
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				mainGUI inst = new mainGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	private void UpMouseClicked(MouseEvent evt) {
		UpComputer up = new UpComputer();
		up.skip();
		this.setVisible(false);
	}
	
	private void DownMouseClicked(MouseEvent evt) {
		DownComputer down = new DownComputer();
		down.skip();
		this.setVisible(false);
	}
}
