package com.netbar.GUI;
import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;

import com.netbar.dao.Computer;
import com.netbar.dao.ComputerDAO;
import com.netbar.service.ManageSystem;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class UpComputer extends javax.swing.JFrame {
	private JPanel jPanel1;
	private JButton jButton1;
	private JButton jButton2;
	private JTextField jTextField2;
	private JLabel jLabel2;
	private JTextField jTextField1;
	private JLabel jLabel1;

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				UpComputer inst = new UpComputer();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public UpComputer() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, BorderLayout.CENTER);
				jPanel1.setLayout(null);
				jPanel1.setPreferredSize(new java.awt.Dimension(349, 261));
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("\u7535\u8111\u7f16\u53f7\uff1a");
					jLabel1.setBounds(37, 28, 66, 25);
				}
				{
					jTextField1 = new JTextField();
					jPanel1.add(jTextField1);
					jTextField1.setBounds(121, 29, 161, 24);
				}
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2);
					jLabel2.setText("\u8eab\u4efd\u8bc1\u53f7\uff1a");
					jLabel2.setBounds(37, 107, 70, 17);
				}
				{
					jTextField2 = new JTextField();
					jPanel1.add(jTextField2);
					jTextField2.setBounds(119, 100, 161, 24);
				}
				{
					jButton1 = new JButton();
					jPanel1.add(jButton1);
					jButton1.setText("\u8fd4\u56de");
					jButton1.setBounds(66, 193, 70, 38);
					jButton1.setFont(new java.awt.Font("΢���ź�",1,14));
					jButton1.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							jButton1MouseClicked(evt);
						}
					});
				}
				{
					jButton2 = new JButton(new ImageIcon("pic/left.gif"));
					jPanel1.add(jButton2);
					jButton2.setText("\u4e0a\u673a");
					jButton2.setBounds(212, 193, 100, 38);
					jButton2.setFont(new java.awt.Font("΢���ź�",1,14));
					jButton2.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							jButton2MouseClicked(evt);
						}
					});
				}
			}
			pack();
			setSize(400, 300);
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}
	
	public void skip()
	{
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				UpComputer inst = new UpComputer();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	private void jButton1MouseClicked(MouseEvent evt) {
		mainGUI main = new mainGUI();
		main.skip();
		this.setVisible(false);
	}
	
	private void jButton2MouseClicked(MouseEvent evt) {
		ManageSystem ms = new ManageSystem();
		ComputerDAO computerdao = new ComputerDAO();
		String perID = jTextField2.getText();
		Date upTime = new Date();
		if(jTextField1.getText().equals(""))
		{
			JOptionPane.showConfirmDialog(null,"��Ų���Ϊ��","��ʾ:", JOptionPane.ERROR_MESSAGE);
			return;
		}
		int comNum = Integer.parseInt(jTextField1.getText());
		Computer computer = computerdao.findById(comNum);
		if(computer == null)
		{
			JOptionPane.showConfirmDialog(null,"����������","��ʾ:", JOptionPane.ERROR_MESSAGE);
			return;
		}
		if(computer.getState() == 1)
		{
			JOptionPane.showConfirmDialog(null,"�õ����Ѿ���ռ��","��ʾ:", JOptionPane.ERROR_MESSAGE);
			return;
		}
		try
		{
			if(perID.length()!=18)
				throw new Exception();
			
		}
		catch(Exception b)
		{
			JOptionPane.showConfirmDialog(null, "����֤��ֻ��Ϊ18λ","��ʾ:", JOptionPane.CLOSED_OPTION);
			return;
		}
		ms.landComputer(perID, comNum, upTime);
		JOptionPane.showMessageDialog(null, "�ϻ��ɹ�");
	}

}
