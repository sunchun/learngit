package com.netbar.GUI;
import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;

import com.netbar.dao.Computer;
import com.netbar.dao.ComputerDAO;
import com.netbar.dao.LandcumputerDAO;
import com.netbar.service.ManageSystem;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class DownComputer extends javax.swing.JFrame {
	private JPanel jPanel1;
	private JButton jButton1;
	private JLabel jLabel5;
	private JLabel jLabel9;
	private JLabel jLabel8;
	private JLabel jLabel7;
	private JLabel jLabel6;
	private JLabel jLabel4;
	private JLabel jLabel3;
	private JButton jButton2;
	private JTextField jTextField2;
	private JLabel jLabel2;
	private JTextField jTextField1;
	private JLabel jLabel1;

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				DownComputer inst = new DownComputer();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public DownComputer() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, BorderLayout.CENTER);
				jPanel1.setLayout(null);
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("\u7535\u8111\u7f16\u53f7\uff1a");
					jLabel1.setBounds(48, 44, 67, 33);
				}
				{
					jTextField1 = new JTextField();
					jPanel1.add(jTextField1);
					jTextField1.setBounds(133, 44, 131, 24);
				}
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2);
					jLabel2.setText("\u8eab\u4efd\u8bc1\u53f7\uff1a");
					jLabel2.setBounds(48, 109, 73, 17);
				}
				{
					jTextField2 = new JTextField();
					jPanel1.add(jTextField2);
					jTextField2.setBounds(133, 106, 131, 24);
				}
				{
					jButton1 = new JButton(new ImageIcon("pic/ok.gif"));
					jPanel1.add(jButton1);
					jButton1.setText("\u7ed3\u8d26");
					jButton1.setBounds(96, 272, 94, 36);
					jButton1.setFont(new java.awt.Font("΢���ź�",1,14));
					jButton1.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							jButton1MouseClicked(evt);
						}
					});
				}
				{
					jButton2 = new JButton(new ImageIcon("pic/left.gif"));
					jPanel1.add(jButton2);
					jButton2.setText("\u4e0b\u673a");
					jButton2.setBounds(238, 272, 92, 35);
					jButton2.setFont(new java.awt.Font("΢���ź�",1,14));
					jButton2.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							jButton2MouseClicked(evt);
						}
					});
				}
				{
					jLabel3 = new JLabel();
					jPanel1.add(jLabel3);
					jLabel3.setText("\u672c\u6b21\u7d2f\u8ba1\u4e0a\u7f51");
					jLabel3.setBounds(73, 171, 83, 20);
					jLabel3.setFont(new java.awt.Font("Microsoft YaHei UI",1,12));
				}
				{
					jLabel4 = new JLabel();
					jPanel1.add(jLabel4);
					jLabel4.setBounds(168, 173, 34, 18);
				}
				{
					jLabel5 = new JLabel();
					jPanel1.add(jLabel5);
					jLabel5.setText("\u5c0f\u65f6");
					jLabel5.setBounds(220, 167, 38, 24);
					jLabel5.setFont(new java.awt.Font("Microsoft YaHei UI",1,12));
				}
				{
					jLabel6 = new JLabel();
					jPanel1.add(jLabel6);
					jLabel6.setText("\uff08\u4e0d\u6ee1\u4e00\u4e2a\u5c0f\u65f6\u4ee5\u4e00\u4e2a\u5c0f\u65f6\u8ba1\uff09");
					jLabel6.setBounds(73, 197, 168, 17);
					jLabel6.setFont(new java.awt.Font("Microsoft YaHei UI",1,12));
				}
				{
					jLabel7 = new JLabel();
					jPanel1.add(jLabel7);
					jLabel7.setText("\u5171\u8ba1");
					jLabel7.setBounds(126, 226, 37, 26);
					jLabel7.setFont(new java.awt.Font("Microsoft YaHei UI",1,12));
				}
				{
					jLabel8 = new JLabel();
					jPanel1.add(jLabel8);
					jLabel8.setBounds(159, 226, 43, 20);
				}
				{
					jLabel9 = new JLabel();
					jPanel1.add(jLabel9);
					jLabel9.setText("\u5143");
					jLabel9.setBounds(220, 227, 21, 25);
					jLabel9.setFont(new java.awt.Font("Microsoft YaHei UI",1,12));
				}
			}
			pack();
			this.setSize(400, 381);
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}
	
	public void skip()
	{
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				DownComputer inst = new DownComputer();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	private void jButton1MouseClicked(MouseEvent evt) {
		mainGUI main = new mainGUI();
		main.skip();
		this.setVisible(false);
	}
	
	private void jButton2MouseClicked(MouseEvent evt) {
		ManageSystem ms = new ManageSystem();
		ComputerDAO computerdao = new ComputerDAO();
		LandcumputerDAO landcumputer = new LandcumputerDAO();
		String perID = jTextField2.getText();
		Date upTime = new Date();
		if(jTextField1.getText().equals(""))
		{
			JOptionPane.showConfirmDialog(null,"��Ų���Ϊ��","��ʾ:", JOptionPane.ERROR_MESSAGE);
			return;
		}
		int comNum = Integer.parseInt(jTextField1.getText());
		Computer computer = computerdao.findById(comNum);
		if(computer == null)
		{
			JOptionPane.showConfirmDialog(null,"����������","��ʾ:", JOptionPane.ERROR_MESSAGE);
			return;
		}
		if(computer.getState() == 0)
		{
			JOptionPane.showConfirmDialog(null,"�õ�������ʹ��","��ʾ:", JOptionPane.ERROR_MESSAGE);
			return;
		}
		try
		{
			if(perID.length()!=18)
				throw new Exception();
			
		}
		catch(Exception b)
		{
			JOptionPane.showConfirmDialog(null, "����֤��ֻ��Ϊ18λ","��ʾ:", JOptionPane.CLOSED_OPTION);
			return;
		}
		if(landcumputer.findById(perID).getComputerId() != comNum)
		{
			JOptionPane.showConfirmDialog(null,"���������ݲ�ƥ��","��ʾ:", JOptionPane.ERROR_MESSAGE);
		}
		int hours = ms.logoutCompter(perID, comNum, upTime);
		jLabel4.setText(Integer.toString(hours));
		jLabel8.setText(Double.toString(ms.account(hours, comNum)));
	}

}
