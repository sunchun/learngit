package com.netbar.dao;

import java.util.Date;

/**
 * Landcumputer entity. @author MyEclipse Persistence Tools
 */

public class Landcumputer implements java.io.Serializable {

	// Fields

	private String personId;
	private Integer computerId;
	private Date upTime;

	// Constructors

	/** default constructor */
	public Landcumputer() {
	}

	/** full constructor */
	public Landcumputer(String personId, Integer computerId, Date upTime) {
		this.personId = personId;
		this.computerId = computerId;
		this.upTime = upTime;
	}

	// Property accessors

	public String getPersonId() {
		return this.personId;
	}

	public void setPersonId(String personId) {
		this.personId = personId;
	}

	public Integer getComputerId() {
		return this.computerId;
	}

	public void setComputerId(Integer computerId) {
		this.computerId = computerId;
	}

	public Date getUpTime() {
		return this.upTime;
	}

	public void setUpTime(Date upTime) {
		this.upTime = upTime;
	}

}